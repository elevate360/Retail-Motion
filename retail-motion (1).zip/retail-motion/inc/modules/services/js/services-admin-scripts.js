//Admin interactivity 
jQuery(document).ready(function($){
	
	//Make the selected services checkboxes sortable in the backend of the single portfolio admin page
	//(lets the user put the serrvice category items in whatever order they want);
});